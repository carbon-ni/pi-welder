/**
 * TASK-0022 — predeclared evidence gate for read-path auto-repair.
 *
 * HISTORICAL EVIDENCE ONLY (TASK-0039): this gate is no longer wired to runtime
 * behavior. Read-path mutation is enabled by the explicit readPathRepairEnabled
 * setting plus an available client. The rule and verdict below stay as the
 * committed record of the offline evaluation.
 *
 * The gate was fixed before evaluation: at least 30 reviewed labels,
 * precision >= 0.99 at the 0.9 confidence threshold, and zero wrong-target
 * selections. The frozen verdict below is the committed outcome.
 */

export const READ_PATH_GATE = Object.freeze({
  minReviewedLabels: 30,
  confidenceThreshold: 0.9,
  minPrecision: 0.99,
  maxWrongTargets: 0,
});

export interface ReadPathEvidence {
  pairs: number;
  /** Human-reviewed labels only; provisional/offline matches do not count. */
  reviewedLabels: number;
  attemptedSelections: number;
  correct: number;
  wrongTargets: number;
  precision: number | undefined;
}

export interface ReadPathVerdict {
  passed: boolean;
  reason: string;
  evidence: ReadPathEvidence;
}

/** Predeclared decision rule — do not tune after seeing results. */
export function evaluateReadPathGate(evidence: ReadPathEvidence): ReadPathVerdict {
  if (evidence.wrongTargets > READ_PATH_GATE.maxWrongTargets) {
    return { passed: false, reason: `wrong-target selections: ${evidence.wrongTargets} > ${READ_PATH_GATE.maxWrongTargets}`, evidence };
  }
  if (evidence.reviewedLabels < READ_PATH_GATE.minReviewedLabels) {
    return { passed: false, reason: `insufficient-reviewed-labels: ${evidence.reviewedLabels} < ${READ_PATH_GATE.minReviewedLabels}`, evidence };
  }
  if ((evidence.precision ?? 0) < READ_PATH_GATE.minPrecision) {
    return { passed: false, reason: `precision ${evidence.precision?.toFixed(3)} < ${READ_PATH_GATE.minPrecision}`, evidence };
  }
  return { passed: true, reason: `precision ${evidence.precision?.toFixed(3)} at ${evidence.reviewedLabels} reviewed labels`, evidence };
}

/**
 * Frozen offline-evaluation outcome (TASK-0022, real corpus, 2026-09-19).
 *
 * See `.tmp/reports/19-09-26/task-0022-read-path-repair.md`. Of **1411 mined
 * pairs**, **747 were candidate-eligible**; deterministic candidate generation
 * reached top-1 8.6% / top-5 14.5% **over those 747**. The bounded Jev probe
 * (cap 200 = 179 unresolved + 21 evaluated = 7 selected + 3 abstain +
 * 11 low-confidence, 2s timeout, zero retries) produced 2 wrong-target
 * selections and zero human-reviewed labels. The gate therefore FAILS. This
 * verdict is kept as evidence, not as a runtime switch.
 */
export const READ_PATH_EVIDENCE: ReadPathVerdict = evaluateReadPathGate({
  pairs: 1411,
  reviewedLabels: 0,
  attemptedSelections: 7,
  correct: 5,
  wrongTargets: 2,
  precision: 5 / 7,
});

/**
 * Candidate-eligibility accounting for the frozen probe. Rates are over
 * `candidateEligible` (747), never over `minedPairs` (1411).
 */
export interface ReadPathAccounting {
  minedPairs: number;
  candidateEligible: number;
  cap: number;
  beyondCap: number;
  unresolved: number;
  evaluated: number;
  statuses: Record<string, number>;
}

export const READ_PATH_ACCOUNTING: ReadPathAccounting = {
  minedPairs: 1411,
  candidateEligible: 747,
  cap: 200,
  beyondCap: 547,
  unresolved: 179,
  evaluated: 21,
  statuses: { selected: 7, abstain: 3, "low-confidence": 11 },
};
