import { resolve } from "node:path";
import { nodeFileSystem, type FileSystem } from "../infra/filesystem.ts";
import { whitespaceNormalizedOffsets } from "./whitespace-normalized.ts";

interface EditInput { oldText: string; newText: string }

const MINIMAL_HUNK_CONTEXT_CHARS = 64;

/**
 * Deterministic preflight: before the built-in `edit` tool runs, expand
 * ambiguous `oldText` values (multiple occurrences) to unique surrounding
 * context so the edit lands in exactly one place.
 *
 * Edits whose `oldText` has zero occurrences cannot be located without an
 * external reasoner; this preflight abstains on those so the tool fails
 * cleanly with its own error. The repair is all-or-nothing: if any pending
 * edit cannot be resolved locally, nothing is mutated.
 */
export async function preflightEditMismatch(input: {
  toolInput: Record<string, unknown>;
  cwd: string;
  fileSystem?: FileSystem;
}): Promise<{ repairedEdits: number } | undefined> {
  const target = input.toolInput.path;
  const edits = parseEdits(input.toolInput.edits);
  if (typeof target !== "string" || edits.length === 0) return undefined;

  const fileSystem = input.fileSystem ?? nodeFileSystem;
  const current = await fileSystem.readFile(resolve(input.cwd, target)).catch(() => undefined);
  if (current === undefined || current.length > 200_000) return undefined;

  const pending = edits
    .map((edit, index) => ({ ...edit, index }))
    .filter(({ oldText, newText }) => countOccurrences(current, oldText) !== 1 && !current.includes(newText));
  if (pending.length === 0) return undefined;

  const local = resolveAmbiguousEdits(current, edits, pending);
  if (!local) return undefined;

  // Missing edits (zero exact occurrences) get one deterministic retry:
  // a unique whitespace-normalized match, then a unique narrowed change
  // hunk. Edits that stay missing abort the whole repair, so the edit fails
  // cleanly with its own error.
  const missing = resolveMissingEdits(current, edits, pending, local);
  if (!missing) return undefined;

  const repairedEdits = edits.map((edit) => ({ ...edit }));
  for (const repair of [...local, ...missing]) {
    repairedEdits[repair.index]!.oldText = repair.oldText;
    repairedEdits[repair.index]!.newText = repair.newText;
  }
  if (!haveNonOverlappingUniqueTargets(current, repairedEdits)) return undefined;

  input.toolInput.edits = repairedEdits;
  return { repairedEdits: local.length + missing.length };
}

function parseEdits(value: unknown): EditInput[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is EditInput => Boolean(item && typeof item === "object" && typeof item.oldText === "string" && typeof item.newText === "string"));
}

function countOccurrences(content: string, value: string): number {
  return occurrenceOffsets(content, value).length;
}

function occurrenceOffsets(content: string, value: string): number[] {
  if (!value) return [];
  const offsets: number[] = [];
  for (let from = 0; (from = content.indexOf(value, from)) !== -1; from += value.length) offsets.push(from);
  return offsets;
}

interface TextRange { start: number; end: number }
interface LocalRepair { index: number; oldText: string; newText: string; range: TextRange }

function resolveAmbiguousEdits(
  current: string,
  edits: EditInput[],
  pending: Array<EditInput & { index: number }>,
): LocalRepair[] | undefined {
  const uniqueRanges = edits.flatMap((edit, index) => {
    const offsets = occurrenceOffsets(current, edit.oldText);
    return offsets.length === 1 ? [{ index, start: offsets[0]!, end: offsets[0]! + edit.oldText.length }] : [];
  });
  const repairs: LocalRepair[] = [];

  for (const edit of pending) {
    const offsets = occurrenceOffsets(current, edit.oldText);
    if (offsets.length < 2) continue;
    const protectedRanges = [
      ...uniqueRanges.filter(({ index }) => index !== edit.index),
      ...repairs.map(({ index, range }) => ({ index, ...range })),
    ];
    const candidates = offsets.flatMap((start) => {
      const originalRange = { start, end: start + edit.oldText.length };
      if (protectedRanges.some((range) => rangesOverlap(originalRange, range))) return [];
      const expanded = findUniqueExpansion(current, edit.oldText, start);
      if (!expanded || protectedRanges.some((range) => rangesOverlap(expanded, range))) return [];
      const prefix = current.slice(expanded.start, start);
      const suffix = current.slice(start + edit.oldText.length, expanded.end);
      return [{ index: edit.index, oldText: current.slice(expanded.start, expanded.end), newText: prefix + edit.newText + suffix, range: expanded }];
    });
    if (candidates.length !== 1) return undefined;
    repairs.push(candidates[0]!);
  }
  return repairs;
}

/**
 * Resolve zero-occurrence oldText values via a unique whitespace-normalized
 * match. oldText becomes the verbatim file slice; newText stays byte-identical
 * (content-safe: only the locator changes, never the intended replacement).
 * Returns undefined when any missing edit cannot be uniquely located.
 */
function resolveMissingEdits(
  current: string,
  edits: EditInput[],
  pending: Array<EditInput & { index: number }>,
  resolved: LocalRepair[],
): LocalRepair[] | undefined {
  const missing = pending.filter(({ oldText }) => countOccurrences(current, oldText) === 0);
  if (missing.length === 0) return [];

  const protectedRanges = [
    ...edits.flatMap((edit, index) => {
      const offsets = occurrenceOffsets(current, edit.oldText);
      return offsets.length === 1 ? [{ start: offsets[0]!, end: offsets[0]! + edit.oldText.length }] : [];
    }),
    ...resolved.map(({ range }) => range),
  ];

  const repairs: LocalRepair[] = [];
  for (const edit of missing) {
    const occupied = [...protectedRanges, ...repairs.map(({ range }) => range)];
    const matches = whitespaceNormalizedOffsets(current, edit.oldText)
      .filter((range) => !occupied.some((occupiedRange) => rangesOverlap(range, occupiedRange)));
    if (matches.length > 1) return undefined;
    if (matches.length === 1) {
      const range = matches[0]!;
      repairs.push({ index: edit.index, oldText: current.slice(range.start, range.end), newText: edit.newText, range });
      continue;
    }

    const narrowed = narrowToUniqueChangeHunk(current, edit, occupied);
    if (!narrowed) return undefined;
    repairs.push({ index: edit.index, ...narrowed });
  }
  return repairs;
}

/**
 * Remove stale unchanged outer context while preserving the exact intended
 * old -> new change. The narrowed locator must still match one current slice
 * exactly, so concurrent content inside the intended hunk is never replaced.
 */
function narrowToUniqueChangeHunk(
  current: string,
  edit: EditInput,
  occupied: TextRange[],
): Omit<LocalRepair, "index"> | undefined {
  if (edit.oldText === edit.newText) return undefined;

  const prefixLength = commonPrefixLength(edit.oldText, edit.newText);
  const suffixLength = commonSuffixLength(edit.oldText, edit.newText, prefixLength);
  const oldChangeEnd = edit.oldText.length - suffixLength;
  const newChangeEnd = edit.newText.length - suffixLength;
  const contextStart = Math.max(0, prefixLength - MINIMAL_HUNK_CONTEXT_CHARS);
  const contextEnd = Math.min(edit.oldText.length, oldChangeEnd + MINIMAL_HUNK_CONTEXT_CHARS);
  const oldText = edit.oldText.slice(contextStart, contextEnd);
  if (oldText.length === 0 || oldText === edit.oldText) return undefined;

  const offsets = occurrenceOffsets(current, oldText);
  if (offsets.length !== 1) return undefined;
  const range = { start: offsets[0]!, end: offsets[0]! + oldText.length };
  if (occupied.some((occupiedRange) => rangesOverlap(range, occupiedRange))) return undefined;

  const leftContext = edit.oldText.slice(contextStart, prefixLength);
  const newChange = edit.newText.slice(prefixLength, newChangeEnd);
  const rightContext = edit.oldText.slice(oldChangeEnd, contextEnd);
  return { oldText, newText: leftContext + newChange + rightContext, range };
}

function commonPrefixLength(left: string, right: string): number {
  const limit = Math.min(left.length, right.length);
  let index = 0;
  while (index < limit && left[index] === right[index]) index++;
  return index;
}

function commonSuffixLength(left: string, right: string, prefixLength: number): number {
  const limit = Math.min(left.length - prefixLength, right.length - prefixLength);
  let length = 0;
  while (length < limit && left[left.length - 1 - length] === right[right.length - 1 - length]) length++;
  return length;
}

function findUniqueExpansion(current: string, oldText: string, start: number): TextRange | undefined {
  const end = start + oldText.length;
  const leftExtra = findMinimumUniqueExtra(start, (extra) => current.slice(start - extra, end), current);
  const rightExtra = findMinimumUniqueExtra(current.length - end, (extra) => current.slice(start, end + extra), current);
  if (leftExtra === undefined && rightExtra === undefined) return undefined;
  if (rightExtra !== undefined && (leftExtra === undefined || rightExtra <= leftExtra)) return { start, end: end + rightExtra };
  return { start: start - leftExtra!, end };
}

function findMinimumUniqueExtra(maxExtra: number, candidateAt: (extra: number) => string, current: string): number | undefined {
  if (maxExtra === 0) return undefined;
  let high = 1;
  while (high < maxExtra && countOccurrences(current, candidateAt(high)) !== 1) high = Math.min(maxExtra, high * 2);
  if (countOccurrences(current, candidateAt(high)) !== 1) return undefined;
  let low = 1;
  while (low < high) {
    const middle = Math.floor((low + high) / 2);
    if (countOccurrences(current, candidateAt(middle)) === 1) high = middle;
    else low = middle + 1;
  }
  return low;
}

function rangesOverlap(left: TextRange, right: TextRange): boolean {
  return left.start < right.end && right.start < left.end;
}

function haveNonOverlappingUniqueTargets(current: string, edits: EditInput[]): boolean {
  const ranges: TextRange[] = [];
  for (const edit of edits) {
    const offsets = occurrenceOffsets(current, edit.oldText);
    if (offsets.length !== 1) continue;
    const range = { start: offsets[0]!, end: offsets[0]! + edit.oldText.length };
    if (ranges.some((existing) => rangesOverlap(existing, range))) return false;
    ranges.push(range);
  }
  return true;
}
